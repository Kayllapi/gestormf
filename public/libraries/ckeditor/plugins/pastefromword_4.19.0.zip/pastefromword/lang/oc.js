/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'oc', {
	confirmCleanup: 'Sembla que lo tèxte de pegar proven de Word. Lo volètz netejar abans de lo pegar ?',
	error: 'Las donadas pegadas an pas pogut èsser netejadas a causa d\'una error intèrna',
	title: 'Pegar dempuèi Word',
	toolbar: 'Pegar dempuèi Word'
} );
