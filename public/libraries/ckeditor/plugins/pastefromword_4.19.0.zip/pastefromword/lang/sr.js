/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'sr', {
	confirmCleanup: 'Уметнути текст је копиран из Word-а.  Желите га очитити? ',
	error: 'Због интерне грешке текст није очишћен.',
	title: 'Залепи из Worda',
	toolbar: 'Залепи из Worda'
} );
