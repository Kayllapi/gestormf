<?php
$estado_activado = DB::table('s_estado')->whereId(1)->first();
$estado_desactivado = DB::table('s_estado')->whereId(2)->first();
$idtabla = explode('#',$tabla);
if($idtabla){
    $idtabla = $idtabla[1];
}
?>
<div id="load-tabla"></div>
<div class="table-responsive">
<table class="table table-striped table-hover" id="{{$idtabla}}">
    @if(isset($thead))
    <thead class="table-dark">
      <tr>
        @foreach($thead as $value)
        @if(isset($value['data']))
        <th <?php echo isset($value['width']) ? 'width="'.$value['width'].'"':'' ?>>{{$value['data']}}</th>
        @endif
        @endforeach
      </tr>
    </thead>
    @endif
    @if(isset($tfoot))
    <tfoot>
      <tr>
        @foreach($tfoot as $value)
          @if(isset($value['type']))
            @if($value['type']=='text')
            <th><input type="text" class="form-control" placeholder="Buscar..."></th>
            @elseif($value['type']=='date')
            <th><input type="date" class="form-control" style="width: 145px;"></th>
            @elseif($value['type']=='select')
            <th>
              <select class="form-select" style="width: 100px;">
                <option value="">Buscar...</option>
                <?php
                $data = $value['data'];
                if($value['data']=='json:estado'){
                    $data = file_get_contents(getcwd().'/public/nuevosistema/librerias/json/estado.json');
                    $data = json_decode($data);
                    $data = $data->data;
                } 
                elseif($value['data']=='json:tipopersona'){
                    $data = file_get_contents(getcwd().'/public/nuevosistema/librerias/json/tipopersona.json');
                    $data = json_decode($data);
                    $data = $data->data;
                }   
                elseif($value['data']=='json:tipomovimiento'){
                    $data = file_get_contents(getcwd().'/public/nuevosistema/librerias/json/tipomovimiento.json');
                    $data = json_decode($data);
                    $data = $data->data;
                } 
                elseif($value['data']=='json:tipodocumento'){
                    $data = file_get_contents(getcwd().'/public/nuevosistema/librerias/json/tipodocumento.json');
                    $data = json_decode($data);
                    $data = $data->data;
                } 
                ?>
                @foreach($data as $listval)
                  <?php 
                  if(is_array($listval)) {
                      $listval = (object) $listval;
                  }
                  ?>
                  <option value="{{$listval->text}}">{{$listval->text}}</option>
                @endforeach
              </select>
            </th>
            @else
            <th></th>
            @endif
          @endif
        @endforeach
      </tr>
    </tfoot>
    @endif
</table>
</div>
<style>
  .columdata{
      width: unset !important;
  }
</style>
<?php
function generar_token_seguro($longitud)
{
    if ($longitud < 4) {
        $longitud = 4;
    }
 
    return bin2hex(random_bytes(($longitud - ($longitud % 2)) / 2));
}
?>
<script>
    
    var table = $('{{$tabla}}').DataTable({
        ajax: {
            url:'{{$route}}',
            /*error: function(xhr, error, code) {
                alert('hay errro!!')
            }*/
        },
        dom: 'rti',
        scrollX: false,
        mark: true,
        select: {
            toggleable: false,
            selector: 'td:not(:nth-child(10))'
        },
        keys: true,
        scrollY: 400,
        scroller: {
            loadingIndicator: true
        },
        ordering: false,
        colReorder: false,
        //order: [[ 1, "asc" ]],
        language: {
            info: "Mostrando _START_ de _TOTAL_ entradas",
            paginate: {
                previous: "Anterior",
                next: "Siguiente"
            },
            select: {
                rows: ""
            },
            processing:"Cargando...",
            emptyTable: "No hay datos disponibles en la tabla"
        },
        initComplete: function () {
          this.api().columns().every( function () {
              var that = this;
              $( 'input', this.footer() ).on( 'keyup change clear', function () {
                  if ( that.search() !== this.value ) {
                      that
                          .search( this.value )
                          .draw();
                  }
              } );
              $( 'select', this.footer() ).on( 'keyup change clear', function () {
                  if ( that.search() !== this.value ) {
                      that
                          .search( this.value )
                          .draw();
                  }
              } );
          } );
        },
        createdRow: function( row, data, dataIndex ) {
            $(row).addClass(data.style);
        },
        columns: [
            @foreach($tbody as $value)
                  @if(isset($value['type']))
                      @if($value['type']=='img')
                      {
                          render: function ( data, type, full, meta ) {
                              return '<div class="img" style="background-image: url('+full.{{$value['data']}}+');"></div>';
                          },
                          className: 'table-type-img',
                          orderable: false,
                      },
                      @elseif($value['type']=='badge')
                      {
                          render: function ( data, type, full, meta ) {
                              var estado = '<span class="badge rounded-pill text-bg-dark">{{$estado_desactivado->nombre}}</span>';
                              if(full.{{$value['data']}}==1){
                                  estado = '<span class="badge rounded-pill text-bg-success">{{$estado_activado->nombre}}</span>';
                              }
                              return estado;
                          },
                          className: 'table-type-badge'
                      },
                      @elseif($value['type']=='code')
                      { 
                          data: "{{$value['data']}}",
                          className: 'table-type-code',
                      },
                      @elseif($value['type']=='date')
                      { 
                          data: "{{$value['data']}}",
                          className: 'table-type-date',
                      },
                      @elseif($value['type']=='text')
                      { 
                          data: "{{$value['data']}}",
                          className: 'table-type-text',
                      },
                      @elseif($value['type']=='num')
                      { 
                          data: "{{$value['data']}}",
                          className: 'table-type-num',
                      },
                      @elseif($value['type']=='ajust')
                      { 
                          data: "{{$value['data']}}",
                          className: 'table-type-ajust',
                      },
                      @elseif($value['type']=='money')
                      { 
                          data: "{{$value['data']}}",
                          className: 'table-type-money',
                      },
                      @elseif($value['type']=='select')
                      { 
                          data: "{{$value['data']}}",
                          className: 'table-type-select',
                      },
                      @elseif($value['type']=='estado')
                      { 
                          data: "{{$value['data']}}",
                          className: 'table-type-estado',
                      },
                      @elseif($value['type']=='btn')
                      {  
                          render: function ( data, type, full, meta ) {
                              var btn = '';
                              if(full.{{$value['data']}}[0]!=undefined){
                                 btn = '<div class="dropdown" id="menu-opcion">'+
                                            '<button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">'+
                                              'Opción'+
                                            '</button>'+
                                            '<ul class="dropdown-menu dropdown-menu-end">'+
                                            '</ul>'+
                                          '</div>';
                              }
                            
                              return btn;
                          },
                          className: 'table-type-btn',
                          orderable: false, 
                      },
                      @endif
                  @else
                  @endif
            @endforeach
        ],
    });
  
    // MOSTRAR ERROR DE TABLA
    $.fn.dataTable.ext.errMode = function ( settings, helpPage, message ) { 
        console.log(message);
    };

    table.on('click', 'tr', function () {
        var data = table.row(this).data();
        $('{{$tabla}} tbody .selected').removeClass('selected');
        $(this).addClass('selected');
    });
  
    
    // Se muestra el botón opción
    table.on( 'click', 'div#menu-opcion', function () {

        var data    = table.row($(this).parents('tr')).data();
        var row     = $(this).find('ul');
        var opcion_html = '';
        $.each(data.opcion, function( key, value ) {
            if(value.nombre!=undefined){
            opcion_html = opcion_html+'<li><a class="dropdown-item" href="javascript:;" onclick="'+value.onclick+'"><i class="fa-solid fa-'+value.icono+'"></i> '+value.nombre+'</a></li>';
            }
        });
        $(row).html(opcion_html);
    });
  
    // subir y bajar por medio de teclado
    table.on('key-focus', function (e, datatable, cell) {
        datatable.rows().deselect();
        datatable.row( cell.index().row ).select();
   
    });
    // enter para abrir detalle
    table.on( 'key', function ( e, datatable, key, cell, originalEvent ) {
        if(key === 13){
            $('.selected').dblclick();
        }
    });
</script>